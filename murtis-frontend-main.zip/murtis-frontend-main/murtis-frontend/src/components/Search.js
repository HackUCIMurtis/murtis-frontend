import React, {Component} from 'react';
import { Row } from 'react-bootstrap';
import { Col } from 'react-bootstrap';
import {InputGroup, Button, Form, FormControl} from 'react-bootstrap';
import "../styles/login.css";
// import {connect} from 'react-redux';
// import {login} from '../../store/actions/authActions';
// import {Redirect, Link} from 'react-router-dom';

class Search extends Component{
    constructor(props){
        super(props);
        this.state={email: "", password: ""};
    }


    render(){

        return(
            <div><p>asdfsafsfd</p></div>
        )
    }
}

export default Search;